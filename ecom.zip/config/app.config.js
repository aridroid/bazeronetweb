module.exports = {
    secretKey: '01GTfhy215475Sdjkj'
}