'use strict';

const morgan = require('morgan');
const bodyParser = require('body-parser');
const contentLength = require('express-content-length-validator');
const helmet = require('helmet');
const compression = require('compression');
const zlib = require('zlib');

module.exports = class RouteConfig {
    static init(app) {
        // app.use(compression({
        //     level: zlib.Z_BEST_COMPRESSION,
        //     threshold: '1kb'
        // }));

        // app.use(bodyParser.urlencoded({
        //     extended: true
        // }));
        app.use(bodyParser.json({ limit: '500mb', extended: true }));
        //app.use(bodyParser({ limit: '50mb' }));
        app.use(bodyParser.urlencoded({ limit: '500mb', extended: true, parameterLimit:50000 }));
        app.use(morgan('dev'));
        app.use(contentLength.validateMax({ max: '500mb' })); 
        app.use(helmet());
    }
}
