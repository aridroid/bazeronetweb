'use strict';

const jsonwebtoken = require('jsonwebtoken');
const secretKey = require('../config/app.config').secretKey;
const AuthService = require('../api/auth/service/auth.service');
const userSchema = require('../api/auth/model/auth.model');
const mongoose = require('mongoose')
  , Schema = mongoose.Schema;

module.exports = class AuthTokenService {

  static isAuthenticated(req, res, next) {
    let token = req.headers.token;
    console.log(token);
    if (token) {
      jsonwebtoken.verify(token, secretKey, function (error, decoded) {
        if (error) {
          res.status(401).json({
            invalidToken: true,
            error: error
          })
        } else {
          req.decoded = decoded;
          return next();
        }
      })
    } else {
      res.status(401).json({
        success: false,
        token: 'no token found'
      })
    }
  }
  
  static isAdmin(req, res, next) {
    let token = req.headers.token;
    if (token) {
      jsonwebtoken.verify(token, secretKey, function (error, decoded) {
        let id = decoded.id;
        if (id) {
          const User = mongoose.model('User', userSchema);
          User.findById(id)
            .exec((err, user) => {
              if (err) {
                res.status(401).json({
                  success: false,
                  token: 'not authorize'
                });
              } else {
                console.log(user.role)
                if (user && user.role == 'admin') {
                  req.decoded = decoded;
                  return next();
                } else {
                  res.status(401).json({
                    success: false,
                    token: 'not authorize'
                  });
                }
              }
            });
        } else {
          res.status(401).json({
            success: false,
            token: 'not authorize'
          });
        }
      })
    } else {
      res.status(401).json({
        success: false,
        token: 'not authorize'
      })
    }
  }

}
