'use strict';

const cors = require('cors');
const methodOverride = require('method-override');
const express = require('express');

const AuthRoutes = require('../api/auth/route/auth.route');
const CategoryRoutes = require('../api/category/route/category.route');
const SubCategoryRoutes = require('../api/sub-category/route/sub-category.route');
const ManufacturerRoutes = require('../api/manufacturer/route/manufacturer.route');
const ProductRoutes = require('../api/product/route/product.route');
const AttributeRoutes = require('../api/attribute/route/attribute.route');
const CartRoutes = require('../api/cart/route/cart.route');
const OrderRoutes = require('../api/order/route/order.route');
const AddressRoutes = require('../api/address/route/address.route');
const BannerRoutes = require('../api/banner/route/banner.route');
const PageRoutes = require('../api/page/route/page.route');

const StaticDispatcher = require('../commons/static/index');



module.exports = class Routes {
  static init(app, router) {
    AuthRoutes.init(router);
    CategoryRoutes.init(router);
    SubCategoryRoutes.init(router);
    ManufacturerRoutes.init(router);
    ProductRoutes.init(router);
    AttributeRoutes.init(router);
    CartRoutes.init(router);
    OrderRoutes.init(router);
    AddressRoutes.init(router);
    BannerRoutes.init(router);
    PageRoutes.init(router);
    
    app.use(cors());
    app.use(methodOverride());
    app.use('/uploads', express.static('uploads'));
    
    router
      .route('*')
      .get(StaticDispatcher.sendIndex);


    app.use('/', router);
  }
}
