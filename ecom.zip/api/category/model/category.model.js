'use strict';

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const _categorySchema = mongoose.Schema({
    name: { type: String, required: true, unique: true },
    description: { type: String },
    image: { type: String },
    status: { type: Boolean, default: true },
    sort_order: { type: Number, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

_categorySchema.plugin(uniqueValidator, { message: 'Category {PATH} should be unique.' });
module.exports = _categorySchema;
