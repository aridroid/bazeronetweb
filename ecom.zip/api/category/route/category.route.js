'use strict';

const CategoryController = require('../controller/category.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class CategoryRoutes {
  static init(router) {
    router
      .route('/api/category')
      //.get(AuthTokenService.isAuthenticated)
      //.get(AuthTokenService.isAdmin)
      .get(CategoryController.getAll)
      .post(CategoryController.create);

    router
      .route('/api/category/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(CategoryController.uploadImage)
      .put(CategoryController.update)
      .get(CategoryController.getById)
      .delete(CategoryController.delete);

    router
      .route('/api/category/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(CategoryController.uploadImage);
  }
}
