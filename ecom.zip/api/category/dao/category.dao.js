'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');
const fs = require('fs');
var Jimp = require('jimp');

const categorySchema = require('../model/category.model');

categorySchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Category.find(_query)
      .sort('sort_order')
      .exec((err, category) => {
        err ? reject(err)
          : resolve(category);
      });
  });
};

categorySchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Category.findById(id)
      .exec((err, category) => {
        err ? reject(err)
          : resolve(category);
      });
  });
}

categorySchema.statics.create = (category) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(category)) {
      return reject(new TypeError('Category is not a valid object.'));
    }

    let _category = new Category(category);
    _category.save((err, saved) => {
      err ? reject(err)
        : resolve(_category);
    });
  });
}

categorySchema.statics.update = (_id, category) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Category.findByIdAndUpdate(_id, {
      $set: category
    })
      .exec((err, category) => {
        err ? reject(err)
          : resolve(category);
      })
  });
}

categorySchema.statics.updateImage = (_id, category) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Category.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': category.image } })
      .exec((err, category) => {
        err ? reject(err)
          : resolve(category);
      })
  });
}

categorySchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Category.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Category = mongoose.model('Category', categorySchema);

module.exports = Category;
