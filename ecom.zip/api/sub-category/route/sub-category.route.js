'use strict';

const SubCategoryController = require('../controller/sub-category.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class SubCategoryRoutes {
  static init(router) {
    router
      .route('/api/sub-category')
      //.get(AuthTokenService.isAuthenticated)
      .get(SubCategoryController.getAll)
      .post(SubCategoryController.create);

    router
      .route('/api/sub-category/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(SubCategoryController.uploadImage)
      .put(SubCategoryController.update)
      .get(SubCategoryController.getById)
      .delete(SubCategoryController.delete);

    router
      .route('/api/sub-category/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(SubCategoryController.uploadImage);

    router
      .route('/api/sub-category/category/:category')
      //.get(AuthTokenService.isAuthenticated)
      .get(SubCategoryController.getByCategory);
  }
}
