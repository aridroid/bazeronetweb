'use strict';

const multer = require('multer');
const fs = require('fs');
const createError = require('http-errors');

const SubCategoryDAO = require('../dao/sub-category.dao');

// SET STORAGE
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, req.params.id + '.png');
  }
})

const upload = multer({ storage: storage }).fields([
  { name: 'image', maxCount: 1 }
]);

module.exports = class CategoryController {
  static async getAll(req, res) {
    try {
      const subCategories = await SubCategoryDAO.getAll();
      res.status(200).json(subCategories);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const subCategories = await SubCategoryDAO.getById(req.params.id);
      res.status(200).json(subCategories);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getByCategory(req, res) {
    try {
      const subCategories = await SubCategoryDAO.getByCategory(req.params.category);
      res.status(200).json(subCategories);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _subCategory = req.body;

    try {
      const subCategories = await SubCategoryDAO.create(_subCategory);
      res.status(200).json(subCategories);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _subCategory = req.body;
    console.log(_id)
    console.log(_subCategory)
    try {
      const subCategories = await SubCategoryDAO.update(_id, _subCategory);
      res.status(200).json(subCategories);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    if (fs.existsSync('uploads/' + _id + '.png')) {
      fs.unlinkSync('uploads/' + _id + '.png');
    }

    try {
      const subCategories = await SubCategoryDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static uploadImage(req, res) {
    let _id = req.params.id;
    let _subCategory = {};

    upload(req, res, function (err) {
      if (err) {
        return res.status(400).json(err);
      }
      const fileName = req.files.image[0].filename;
      _subCategory.image = fileName;

      SubCategoryDAO
        .updateImage(_id, _subCategory)
        .then(subCategories => res.status(200).json(subCategories))
        .catch(error => res.status(400).json(error));
    });
  }
}
