'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const subCategorySchema = require('../model/sub-category.model');
const _ = require('lodash');

subCategorySchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    SubCategory.find(_query)
      .populate('category')
      .exec((err, subCategory) => {
        err ? reject(err)
          : resolve(subCategory);
      });
  });
};

subCategorySchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    SubCategory.findById(id)
      .populate('category')
      .exec((err, subCategory) => {
        err ? reject(err)
          : resolve(subCategory);
      });
  });
}

subCategorySchema.statics.getByCategory = (category) => {
  return new Promise((resolve, reject) => {
    let _query = {category: category};
    if (!category) {
      return reject(new TypeError('category is not defined.'));
    }

    SubCategory.find(_query)
      .populate('category')
      .exec((err, subCategory) => {
        err ? reject(err)
          : resolve(subCategory);
      });
  });
}

subCategorySchema.statics.create = (subCategory) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(subCategory)) {
      return reject(new TypeError('SubCategory is not a valid object.'));
    }

    let _subCategory = new SubCategory(subCategory);

    _subCategory.save((err, saved) => {
      err ? reject(err)
        : resolve(saved);
    });
  });
}

subCategorySchema.statics.update = (_id, subCategory) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    SubCategory.findByIdAndUpdate(_id, {
      $set: subCategory
    })
      .exec((err, subCategory) => {
        err ? reject(err)
          : resolve(subCategory);
      })
  });
}

subCategorySchema.statics.updateImage = (_id, subCategory) => {
  console.log(subCategory);
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    SubCategory.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': subCategory.image } })
      .exec((err, subCategory) => {
        err ? reject(err)
          : resolve(subCategory);
      })
  });
}


subCategorySchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    SubCategory.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const SubCategory = mongoose.model('SubCategory', subCategorySchema);

module.exports = SubCategory;
