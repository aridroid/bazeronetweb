'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
const uniqueValidator = require('mongoose-unique-validator');

const categorySchema = require('../../category/model/category.model');
const category = mongoose.model('category', categorySchema);

const _subCategorySchema = mongoose.Schema({
    category: { type: Schema.Types.ObjectId, ref: 'category', required: true },
    name: { type: String, required: true, unique: true },
    description: { type: String },
    image: { type: String },
    status: { type: Boolean, default: true },
    sort_order: { type: Number, required: true },
    date_added: { type: Date, default: Date.now },
    date_modified: { type: Date, default: Date.now }
})

_subCategorySchema.plugin(uniqueValidator, { message: 'Category {PATH} should be unique.' });
module.exports = _subCategorySchema;