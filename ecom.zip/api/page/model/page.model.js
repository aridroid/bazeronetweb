'use strict';

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const _pageSchema = mongoose.Schema({
    title: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    image: { type: String },
    status: { type: Boolean, default: true },
    sort_order: { type: Number, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

_pageSchema.plugin(uniqueValidator, { message: 'Page {PATH} should be unique.' });
module.exports = _pageSchema;
