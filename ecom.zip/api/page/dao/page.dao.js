'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');
const fs = require('fs');
var Jimp = require('jimp');

const pageSchema = require('../model/page.model');

pageSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Page.find(_query)
      .sort('sort_order')
      .exec((err, page) => {
        err ? reject(err)
          : resolve(page);
      });
  });
};

pageSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Page.findById(id)
      .exec((err, page) => {
        err ? reject(err)
          : resolve(page);
      });
  });
}

pageSchema.statics.create = (page) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(page)) {
      return reject(new TypeError('Page is not a valid object.'));
    }

    let _page = new Page(page);
    _page.save((err, saved) => {
      err ? reject(err)
        : resolve(_page);
    });
  });
}

pageSchema.statics.update = (_id, page) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Page.findByIdAndUpdate(_id, {
      $set: page
    })
      .exec((err, page) => {
        err ? reject(err)
          : resolve(page);
      })
  });
}

pageSchema.statics.updateImage = (_id, page) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Page.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': page.image } })
      .exec((err, page) => {
        err ? reject(err)
          : resolve(page);
      })
  });
}

pageSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Page.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Page = mongoose.model('Page', pageSchema);

module.exports = Page;
