'use strict';

const multer = require('multer');
const fs = require('fs');
const createError = require('http-errors');
const PageDAO = require('../dao/page.dao');

// SET STORAGE
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, req.params.id + '.png');
  }
})

const upload = multer({ storage: storage }).fields([
  { name: 'image', maxCount: 1 }
]);

module.exports = class PageController {
  static async getAll(req, res) {
    try {
      const pages = await PageDAO.getAll();
      res.status(200).json(pages);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const pages = await PageDAO.getById(req.params.id);
      res.status(200).json(pages);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _page = req.body;

    try {
      const pages = await PageDAO.create(_page);
      res.status(200).json(pages);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _page = req.body;

    try {
      const pages = await PageDAO.update(_id, _page);
      res.status(200).json(pages);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    if (fs.existsSync('uploads/' + _id + '.png')) {
      fs.unlinkSync('uploads/' + _id + '.png');
    }

    try {
      const pages = await PageDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static uploadImage(req, res) {
    let _id = req.params.id;
    let _page = {};

    upload(req, res, function (err) {
      if (err) {
        return res.status(400).json(err);
      }
      const fileName = req.files.image[0].filename;
      _page.image = fileName;

      PageDAO
        .updateImage(_id, _page)
        .then(pages => res.status(200).json(pages))
        .catch(error => res.status(400).json(error));
    });
  }
}

