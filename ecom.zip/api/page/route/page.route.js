'use strict';

const PageController = require('../controller/page.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class PageRoutes {
  static init(router) {
    router
      .route('/api/page')
      //.get(AuthTokenService.isAuthenticated)
      .get(PageController.getAll)
      .post(PageController.create);

    router
      .route('/api/page/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(PageController.uploadImage)
      .put(PageController.update)
      .get(PageController.getById)
      .delete(PageController.delete);

    router
      .route('/api/page/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(PageController.uploadImage);
  }
}
