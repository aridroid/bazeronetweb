'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');
const fs = require('fs');
var Jimp = require('jimp');

const attributeSchema = require('../model/attribute.model');

attributeSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Attribute.find(_query)
      .exec((err, attribute) => {
        err ? reject(err)
          : resolve(attribute);
      });
  });
};

attributeSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Attribute.findById(id)
      .exec((err, attribute) => {
        err ? reject(err)
          : resolve(attribute);
      });
  });
}

attributeSchema.statics.create = (attribute) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(attribute)) {
      return reject(new TypeError('Attribute is not a valid object.'));
    }

    let _attribute = new Attribute(attribute);
    _attribute.save((err, saved) => {
      err ? reject(err)
        : resolve(_attribute);
    });
  });
}

attributeSchema.statics.update = (_id, attribute) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Attribute.findByIdAndUpdate(_id, {
      $set: attribute
    })
      .exec((err, attribute) => {
        err ? reject(err)
          : resolve(attribute);
      })
  });
}

attributeSchema.statics.updateImage = (_id, attribute) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Attribute.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': attribute.image } })
      .exec((err, attribute) => {
        err ? reject(err)
          : resolve(attribute);
      })
  });
}

attributeSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Attribute.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Attribute = mongoose.model('Attribute', attributeSchema);

module.exports = Attribute;
