'use strict';

const AttributeController = require('../controller/attribute.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class AttributeRoutes {
  static init(router) {
    router
      .route('/api/attribute')
      //.get(AuthTokenService.isAuthenticated)
      .get(AttributeController.getAll)
      .post(AttributeController.create);

    router
      .route('/api/attribute/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(AttributeController.update)
      .get(AttributeController.getById)
      .delete(AttributeController.delete);
  }
}
