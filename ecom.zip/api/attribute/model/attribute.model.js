'use strict';

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const _attributeSchema = mongoose.Schema({
    weight: [{ type: String }],
    length: [{ type: String }],
    packaging: [{ type: String }]
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

_attributeSchema.plugin(uniqueValidator, { message: 'Attribute {PATH} should be unique.' });
module.exports = _attributeSchema;
