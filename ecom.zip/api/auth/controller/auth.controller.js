'use strict';

const AuthService = require('../service/auth.service');
const jsonwebtoken = require('jsonwebtoken');

module.exports = class AuthController {

  static login(req, res, next) {
    let user = req.body;
    AuthService
      .login(user)
      .then(obj => {
        res.status(200).json({
          loggedin: true,
          _id: obj.user._id,
          email: obj.user.email,
          name: obj.user.name,
          token: obj.token
        })
      })
      .catch(error => {
        res.status(400).json({
          loggedin: false,
          error: error
        })
      });
  }

  static adminlogin(req, res, next) {
    let user = req.body;
    AuthService
      .adminlogin(user)
      .then(obj => {
        res.status(200).json({
          loggedin: true,
          _id: obj.user._id,
          email: obj.user.email,
          name: obj.user.name,
          token: obj.token
        })
      })
      .catch(error => {
        res.status(400).json({
          loggedin: false,
          error: error
        })
      });
  }

  static getAll(req, res) {
      AuthService
        .getAll()
        .then(users => res.status(200).json(users))
        .catch(error => res.status(400).json(error));
  }

  static getById(req, res) {
      AuthService
        .getById(req.params.id)
        .then(user => res.status(200).json(user))
        .catch(error => res.status(400).json(error));
  }

  static async count(req, res) {
    try {
      const users = await AuthService.count();
      res.status(200).json(users);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static updateUser(req, res) {
    let _user = req.body;
    console.log(req.params.id)
      AuthService
        .updateUser(req.params.id, _user)
        .then(user => res.status(200).json(user))
        .catch(error => res.status(400).json(error));
  }

  static createUser(req, res) {
      let _user = req.body;

      AuthService
        .createUser(_user)
        .then(user => res.status(201).json(user))
        .catch(error => res.status(400).json(error));
  }

  static verifyUser(req, res) {
    let _user = req.body;
      AuthService
        .verifyUser(req.params.id, _user)
        .then(user => res.status(200).json(user))
        .catch(error => res.status(400).json(error));
  }

  static sendCodeForResetPassword(req, res) {
    let _user = req.body;
      AuthService
        .sendCodeForResetPassword(_user)
        .then(user => res.status(200).json(user))
        .catch(error => res.status(400).json(error));
  }

  static resetPassword(req, res) {
    let _user = req.body;
      AuthService
        .resetPassword(req.params.id, _user)
        .then(user => res.status(200).json(user))
        .catch(error => res.status(400).json(error));
  }

  static deleteUser(req, res) {
    let _id = req.params.id;

    AuthService
      .deleteUser(_id)
      .then(() => res.status(200).end())
      .catch(error => res.status(400).json(error));
  }


}
