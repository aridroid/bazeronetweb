'use strict';

const AuthController = require('../controller/auth.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class UserRoutes {
  static init(router) {
    router
      .route('/api/login')
      .post(AuthController.login);

    router
      .route('/api/signin')
      .post(AuthController.adminlogin);

    router
      .route('/api/users')
      //.get(AuthTokenService.isAuthenticated)
      .get(AuthController.getAll)
      .post(AuthController.createUser);

    router
      .route('/api/users/:id')
      //.get(AuthTokenService.isAuthenticated)
      .get(AuthController.getById)
      .put(AuthController.updateUser)
      .delete(AuthController.deleteUser);

    router
      .route('/api/users/verify/:id')
      .put(AuthController.verifyUser);

    router
      .route('/api/users/code')
      //.get(AuthTokenService.isAuthenticated)
      .post(AuthController.sendCodeForResetPassword);

    router
      .route('/api/users/reset-password/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(AuthController.resetPassword);

    router
      .route('/api/user-count')
      //.get(AuthTokenService.isAuthenticated)
      .get(AuthController.count);

  }
}
