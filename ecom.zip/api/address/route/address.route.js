'use strict';

const AddressController = require('../controller/address.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class AddressRoutes {
  static init(router) {
    router
      .route('/api/address')
      //.get(AuthTokenService.isAuthenticated)
      .get(AddressController.getAll)
      .post(AddressController.create);

    router
      .route('/api/address/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(AddressController.update)
      .get(AddressController.getByCustomerId)
      .delete(AddressController.delete);
  }
}
