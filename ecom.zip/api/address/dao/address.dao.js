'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');

const addressSchema = require('../model/address.model');

addressSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Address.find(_query)
      .exec((err, address) => {
        err ? reject(err)
          : resolve(address);
      });
  });
};

addressSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Address.findById(id)
      .exec((err, address) => {
        err ? reject(err)
          : resolve(address);
      });
  });
}

addressSchema.statics.getByCustomerId = (customer_id) => {
  let _query = { customer_id: customer_id };
  return new Promise((resolve, reject) => {
    if (!customer_id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Address.find(_query)
      .populate('customer_id')
      .exec((err, cart) => {
        err ? reject(err)
          : resolve(cart);
      });
  });
}

addressSchema.statics.create = (address) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(address)) {
      return reject(new TypeError('Address is not a valid object.'));
    }

    let _address = new Address(address);
    _address.save((err, saved) => {
      err ? reject(err)
        : resolve(_address);
    });
  });
}

addressSchema.statics.update = (_id, address) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Address.findByIdAndUpdate(_id, {
      $set: address
    })
      .exec((err, address) => {
        err ? reject(err)
          : resolve(address);
      })
  });
}

addressSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Address.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Address = mongoose.model('Address', addressSchema);

module.exports = Address;
