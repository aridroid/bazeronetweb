'use strict';

const createError = require('http-errors');
const AddressDAO = require('../dao/address.dao');

module.exports = class AddressController {
  static async getAll(req, res) {
    try {
      const addresss = await AddressDAO.getAll();
      res.status(200).json(addresss);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const addresss = await AddressDAO.getById(req.params.id);
      res.status(200).json(addresss);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }
  
  static async getByCustomerId(req, res) {
    try {
      const addresss = await AddressDAO.getByCustomerId(req.params.id);
      res.status(200).json(addresss);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _address = req.body;

    try {
      const addresss = await AddressDAO.create(_address);
      res.status(200).json(addresss);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _address = req.body;

    try {
      const addresss = await AddressDAO.update(_id, _address);
      res.status(200).json(addresss);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    try {
      const carts = await AddressDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }
}

