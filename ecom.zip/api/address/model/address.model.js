'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
const productSchema = require('../../product/model/product.model');
const userSchema = require('../../auth/model/auth.model');
const ProductSchema = mongoose.model('product', productSchema);
const UserSchema = mongoose.model('user', userSchema);

const _addressSchema = mongoose.Schema({
    customer_id: { type: Schema.Types.ObjectId, ref: 'user' },
    type: { type: String, required: true },
    fullName: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: Number, required: true },
    country: { type: String, default: 'India' },
    state: { type: String, required: true },
    city: { type: String, required: true },
    postcode: { type: Number, required: true },
    address: { type: String, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

module.exports = _addressSchema;
