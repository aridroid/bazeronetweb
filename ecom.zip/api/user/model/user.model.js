'use strict';

const mongoose = require('mongoose')
    , Schema = mongoose.Schema;
const uniqueValidator = require('mongoose-unique-validator');

const _userSchema = {
    email: { type: String, unique: true },
    phone: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    password: { type: String, required: true },
    code: { type: Number },
    isVerified: { type: Boolean, default: false },
    image: { type: String },
    role: {
        type: String,
        default: 'customer',
        enum: ["admin", "vendor", "customer"]
    },
    status: { type: Boolean, default: true }
}

const UserSchema = mongoose.Schema(_userSchema, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } });

UserSchema.plugin(uniqueValidator);

module.exports = UserSchema;
