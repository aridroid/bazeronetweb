'use strict';

const UserController = require('../controller/user.controller');
const UserTokenService = require('../../../commons/user-token.service');

module.exports = class UserRoutes {
  static init(router) {
    router
      .route('/api/login')
      .post(UserController.login);

    router
      .route('/api/signin')
      .post(UserController.adminlogin);

    router
      .route('/api/users')
      //.get(UserTokenService.isUserenticated)
      .get(UserController.getAll)
      .post(UserController.createUser);

    router
      .route('/api/users/:id')
      //.get(UserTokenService.isUserenticated)
      .get(UserController.getById)
      .put(UserController.updateUser)
      .delete(UserController.deleteUser);

    router
      .route('/api/users/verify/:id')
      .put(UserController.verifyUser);

    router
      .route('/api/users/code')
      //.get(UserTokenService.isUserenticated)
      .post(UserController.sendCodeForResetPassword);

    router
      .route('/api/users/reset-password/:id')
      //.get(UserTokenService.isUserenticated)
      .post(UserController.resetPassword);

    router
      .route('/api/user-count')
      //.get(UserTokenService.isUserenticated)
      .get(UserController.count);

  }
}
