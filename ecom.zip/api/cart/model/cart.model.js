'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
const productSchema = require('../../product/model/product.model');
const userSchema = require('../../auth/model/auth.model');

const ProductSchema = mongoose.model('product', productSchema);
const UserSchema = mongoose.model('user', userSchema);

const _cartSchema = mongoose.Schema({
    customer_id: { type: Schema.Types.ObjectId, ref: 'user' },
    product: { type: Schema.Types.ObjectId, ref: 'product' },
    quantity: { type: Number, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

module.exports = _cartSchema;
