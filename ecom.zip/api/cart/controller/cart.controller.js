'use strict';

const createError = require('http-errors');
const CartDAO = require('../dao/cart.dao');

module.exports = class CartController {
  static async getAll(req, res) {
    try {
      const carts = await CartDAO.getAll();
      res.status(200).json(carts);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const carts = await CartDAO.getById(req.params.id);
      res.status(200).json(carts);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getByCustomerId(req, res) {
    try {
      const carts = await CartDAO.getByCustomerId(req.params.id);
      res.status(200).json(carts);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _cart = req.body;

    try {
      const carts = await CartDAO.create(_cart);
      res.status(200).json(carts);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _cart = req.body;

    try {
      const carts = await CartDAO.update(_id, _cart);
      res.status(200).json(carts);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    try {
      const carts = await CartDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async deleteAll(req, res) {
    let _ids = req.body.ids;
    try {
      const carts = await CartDAO.deleteMany({_id:{$in:_ids}});
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }
}

