'use strict';

const CartController = require('../controller/cart.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class CartRoutes {
  static init(router) {
    router
      .route('/api/cart')
      //.get(AuthTokenService.isAuthenticated)
      .get(CartController.getAll)
      .post(CartController.create);

    router
      .route('/api/cart/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(CartController.update)
      .get(CartController.getByCustomerId)
      .delete(CartController.delete);

    router
      .route('/api/cart/delete-all')
      //.get(AuthTokenService.isAuthenticated)
      .post(CartController.deleteAll);
  }
}
