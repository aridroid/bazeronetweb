'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');

const cartSchema = require('../model/cart.model');

cartSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Cart.find(_query)
      .populate('product')
      .populate('customer_id')
      .exec((err, cart) => {
        err ? reject(err)
          : resolve(cart);
      });
  });
};

cartSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Cart.findById(id)
      .exec((err, cart) => {
        err ? reject(err)
          : resolve(cart);
      });
  });
}

cartSchema.statics.getByCustomerId = (customer_id) => {
  let _query = { customer_id: customer_id };
  return new Promise((resolve, reject) => {
    if (!customer_id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Cart.find(_query)
      .populate('product')
      .populate('customer_id')
      .exec((err, cart) => {
        err ? reject(err)
          : resolve(cart);
      });
  });
}

cartSchema.statics.create = (cart) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(cart)) {
      return reject(new TypeError('Cart is not a valid object.'));
    }

    let _cart = new Cart(cart);
    _cart.save((err, saved) => {
      err ? reject(err)
        : resolve(_cart);
    });
  });
}

cartSchema.statics.update = (_id, cart) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Cart.findByIdAndUpdate(_id, {
      $set: cart
    })
      .exec((err, cart) => {
        err ? reject(err)
          : resolve(cart);
      })
  });
}


cartSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Cart.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}


cartSchema.statics.deleteAll = (ids) => {
  return new Promise((resolve, reject) => {
    Cart.deleteMany({_id:{$in:["5ef1fe542b35be2eeccc1075","5ef20fd80ecca429384d0c3f"]}})
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Cart = mongoose.model('Cart', cartSchema);

module.exports = Cart;
