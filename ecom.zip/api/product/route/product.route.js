'use strict';

const ProductController = require('../controller/product.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class ProductRoutes {
  static init(router) {
    router
      .route('/api/product')
      //.get(AuthTokenService.isAuthenticated)
      .get(ProductController.getAll)
      .post(ProductController.create);

    router
      .route('/api/product/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(ProductController.uploadImage)
      .put(ProductController.update)
      .get(ProductController.getById)
      .delete(ProductController.delete);

    router
      .route('/api/product/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(ProductController.uploadImage);

    router
      .route('/api/product/image/remove/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(ProductController.removeImage);

    router
      .route('/api/product-search')
      //.get(AuthTokenService.isAuthenticated)
      .get(ProductController.search);

    router
      .route('/api/product-count')
      //.get(AuthTokenService.isAuthenticated)
      .get(ProductController.count);
  }
}
