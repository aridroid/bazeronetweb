'use strict';

const multer = require('multer');
const fs = require('fs');
const createError = require('http-errors');

const ProductDAO = require('../dao/product.dao');

// SET STORAGE
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, `${req.params.id}-` + Date.now() + '.png');
  }
})

const upload = multer({ storage: storage }).fields([
  { name: 'image', maxCount: 6 }
]);

module.exports = class ProductController {
  static async getAll(req, res) {
    try {
      const products = await ProductDAO.getAll();
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const products = await ProductDAO.getById(req.params.id);
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async search(req, res) {
    try {
      const products = await ProductDAO.search(req.query);
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async count(req, res) {
    try {
      const products = await ProductDAO.count();
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _product = req.body;

    try {
      const products = await ProductDAO.create(_product);
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _product = req.body;

    try {
      const products = await ProductDAO.update(_id, _product);
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    fs.readdir('uploads/', function (err, files) {
      if (err) {
        console.error("Could not list the directory.", err);
      }

      files.forEach(function (file, index) {
        console.log(file.split('-')[0]);
        console.log(file.split('-')[0] == _id);
        if(file.split('-')[0] === _id) {
          fs.unlinkSync('uploads/' + file);
        }
      });
    });

    try {
      const products = await ProductDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static uploadImage(req, res) {
    let _id = req.params.id;
    let _product = {
      image: []
    };

    upload(req, res, function (err) {
      if (err) {
        return res.status(400).json(err);
      }

      req.files.image.forEach(element => {
        const fileName = element.filename;
        _product.image.push(fileName);
      });

      //_product.image = fileName;

      ProductDAO
        .updateImage(_id, _product)
        .then(products => res.status(200).json(products))
        .catch(error => res.status(400).json(error));
    });
  }

  static async removeImage(req, res) {
    let _id = req.params.id;
    let _product = req.body;

    if (fs.existsSync('uploads/' + _product.image)) {
      fs.unlinkSync('uploads/' + _product.image);
    }

    try {
      const products = await ProductDAO.removeImage(_id, _product);
      res.status(200).json(products);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }
}
