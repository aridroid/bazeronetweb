'use strict';

const mongoose = require('mongoose'),
  Schema = mongoose.Schema;

const categorySchema = require('../../category/model/category.model');
const SubCategorySchema = require('../../sub-category/model/sub-category.model');
const manufacturerSchema = require('../../manufacturer/model/manufacturer.model');
const category = mongoose.model('category', categorySchema);
const SubCategory = mongoose.model('subcategory', SubCategorySchema);
const manufacturer = mongoose.model('manufacturer', manufacturerSchema);

const _productSchema = {
  category: { type: Schema.Types.ObjectId, ref: 'category' },
  subcategory: { type: String },
  manufacturer: { type: String },
  name: { type: String, required: true },
  description: { type: String, required: true },
  model: { type: String },
  tax: { type: Number, default: 0 },
  image: [{ type: String }],
  price: { type: Number, required: true },
  actual_price: { type: Number, required: true },
  stock: { type: Number, required: true },
  shipping: { type: Number, default: 0 },
  min_amount_for_free_shipping: { type: Number, default: 0 },
  unit: { type: Number, required: true },
  quantity: { type: Number },
  quantity_class: { type: String },
  weight: { type: Number },
  weight_class: { type: String },
  dimensions: {
    length: { type: Number },
    width: { type: Number },
    height: { type: Number }
  },
  dimensions_class: { type: String },
  status: { type: Boolean, default: true },
  total_stock: { type: String },
  current_stock: { type: String },
  block_stock: { type: String },
  sort_order: { type: Number }
}

module.exports = mongoose.Schema(_productSchema, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } });
