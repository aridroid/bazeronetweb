'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const productSchema = require('../model/product.model');
const _ = require('lodash');

productSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Product.find(_query)
      .populate('category')
      .exec((err, product) => {
        err ? reject(err)
          : resolve(product);
      });
  });
};

productSchema.statics.search = (term) => {
  return new Promise((resolve, reject) => {
    let _query = {};
    let sortOrder = '-date_modified';

    console.log(term.minPrice)
    console.log(term.maxPrice)

    if (term.minPrice || term.maxPrice) {
      _query = { 'price': { '$gte': parseInt(term.minPrice), '$lte': parseInt(term.maxPrice) } }
    }

    if (term.subcategory) {
      _query.subcategory = term.subcategory
    }

    if (term.category) {
      _query.category = term.category
    }

    if (term.name) {
      const regex = new RegExp(term.name, 'i');
      _query.name = regex
    }

    if (term.sort) {
      switch (term.sort) {
        case 'newest':
          sortOrder = 'date_added';
          break;
        case 'oldest':
          sortOrder = '-date_added';
          break;
        case 'price_low_to_high':
          sortOrder = 'price';
          break;
        case 'price_high_to_low':
          sortOrder = '-price';
          break;
        default:
          sortOrder = term.sort;
      }
    }

    Product.find(_query)
      .populate('category')
      .sort(sortOrder)
      .exec((err, product) => {
        err ? reject(err)
          : resolve(product);
      });
  });
};

productSchema.statics.count = () => {
  return new Promise((resolve, reject) => {
    Product.countDocuments()
      .exec((err, product) => {
        err ? reject(err)
          : resolve(product);
      });
  });
}

// productSchema.statics.search = (term) => {
//   return new Promise((resolve, reject) => {
//     var regex = new RegExp(term, 'i');
//     let _query = { name: regex };

//     Product.find(_query)
//       .exec((err, products) => {
//         err ? reject(err)
//           : resolve(products);
//       });
//   });
// };

productSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Product.findById(id)
      .exec((err, product) => {
        err ? reject(err)
          : resolve(product);
      });
  });
}

productSchema.statics.create = (product) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(product)) {
      return reject(new TypeError('Product is not a valid object.'));
    }

    let _product = new Product(product);
    _product.save((err, saved) => {
      err ? reject(err)
        : resolve(_product);
    });
  });
}

productSchema.statics.update = (_id, product) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Product.findByIdAndUpdate(_id, {
      $set: product
    })
      .exec((err, product) => {
        err ? reject(err)
          : resolve(product);
      })
  });
}

productSchema.statics.updateStock = (_id, stock) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }
    console.log(stock);
    Product.findByIdAndUpdate(_id, {
      $set: { stock: stock }
    })
      .exec((err, product) => {
        err ? reject(err)
          : resolve({
            success: true
          });
      })
  });
}

productSchema.statics.updateImage = (_id, product) => {

  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Product.getById(_id).then((res) => {
      if (res.image && res.image.length > 0 && res.image[0] != '') {
        console.log(product.image);
        console.log(res.image);
        product.image = [...product.image, ...res.image]
      }

      Product.findOneAndUpdate({ _id: _id },
        { '$set': { 'image': product.image } })
        .exec((err, product) => {
          err ? reject(err)
            : resolve(product);
        })
    }).catch(error => res.status(400).json(error));


  });
}

productSchema.statics.removeImage = (_id, product) => {

  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Product.getById(_id).then((res) => {
      if (res.image.length > 0) {
        if (res.image.indexOf(product.image) != -1) {
          res.image.splice(res.image.indexOf(product.image), 1);
        }
      }

      Product.findOneAndUpdate({ _id: _id },
        { '$set': { 'image': res.image } })
        .exec((err, product) => {
          err ? reject(err)
            : resolve(product);
        })
    }).catch(error => res.status(400).json(error));


  });
}

productSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Product.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
