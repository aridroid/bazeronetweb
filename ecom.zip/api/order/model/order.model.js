'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
const productSchema = require('../../product/model/product.model');
const ProductSchema = mongoose.model('product', productSchema);
const addressSchema = require('../../address/model/address.model');
const AddressSchema = mongoose.model('address', addressSchema);
const userSchema = require('../../auth/model/auth.model');
const UserSchema = mongoose.model('user', userSchema);

const _orderSchema = mongoose.Schema({
    customer_id: { type: Schema.Types.ObjectId, ref: 'user' },
    products: [{
        product: { type: Object },
        quantity: { type: Number }
    }],
    billing_address_id: { type: Object },
    shipping_address_id: { type: Object },
    payment: { type: Number, required: true },
    comment: { type: String },
    total: { type: String },
    status: { type: String, default: 'Received' }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

module.exports = _orderSchema;
