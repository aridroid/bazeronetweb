'use strict';

const createError = require('http-errors');
const OrderDAO = require('../dao/order.dao');

module.exports = class OrderController {
  static async getAll(req, res) {
    try {
      const orders = await OrderDAO.getAll();
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }  

  static async getByCustomerId(req, res) {
    try {
      const orders = await OrderDAO.getByCustomerId(req.params.id);
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }  

  static async search(req, res) {
    try {
      const orders = await OrderDAO.search(req.query);
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async count(req, res) {
    try {
      const orders = await OrderDAO.count();
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const orders = await OrderDAO.getById(req.params.id);
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _order = req.body;

    try {
      const orders = await OrderDAO.create(_order);
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _order = req.body;

    try {
      const orders = await OrderDAO.update(_id, _order);
      res.status(200).json(orders);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }
}

