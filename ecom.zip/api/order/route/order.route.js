'use strict';

const OrderController = require('../controller/order.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class OrderRoutes {
  static init(router) {
    router
      .route('/api/order')
      //.get(AuthTokenService.isAuthenticated)
      .get(OrderController.getAll)
      .post(OrderController.create);

    router
      .route('/api/order/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(OrderController.update)
      .get(OrderController.getById);

    router
      .route('/api/order-search')
      //.get(AuthTokenService.isAuthenticated)
      .get(OrderController.search);


    router
      .route('/api/order-one/:id')
      //.get(AuthTokenService.isAuthenticated)
      .get(OrderController.getByCustomerId);

    router
      .route('/api/order-count')
      //.get(AuthTokenService.isAuthenticated)
      .get(OrderController.count);
  }
}
