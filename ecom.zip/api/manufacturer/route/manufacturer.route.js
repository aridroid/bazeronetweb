'use strict';

const ManufacturerController = require('../controller/manufacturer.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class ManufacturerRoutes {
  static init(router) {
    router
      .route('/api/manufacturer')
      //.get(AuthTokenService.isAuthenticated)
      .get(ManufacturerController.getAll)
      .post(ManufacturerController.create);

    router
      .route('/api/manufacturer/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(ManufacturerController.uploadImage)
      .put(ManufacturerController.update)
      .get(ManufacturerController.getById)
      .delete(ManufacturerController.delete);

    router
      .route('/api/manufacturer/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(ManufacturerController.uploadImage);

    router
      .route('/api/manufacturer-count')
      //.get(AuthTokenService.isAuthenticated)
      .get(ManufacturerController.count);
  }
}
