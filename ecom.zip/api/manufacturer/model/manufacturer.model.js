'use strict';

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const _manufacturerSchema = mongoose.Schema({
    name: { type: String, required: true, unique: true },
    description: { type: String },
    image: { type: String },
    status: { type: Boolean, default: true },
    sort_order: { type: Number, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

_manufacturerSchema.plugin(uniqueValidator, { message: 'Manufacturer {PATH} should be unique.' });
module.exports = _manufacturerSchema;
