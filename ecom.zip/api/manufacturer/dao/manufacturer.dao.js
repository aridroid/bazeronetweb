'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');
const fs = require('fs');
var Jimp = require('jimp');

const manufacturerSchema = require('../model/manufacturer.model');

manufacturerSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Manufacturer.find(_query)
      .exec((err, manufacturer) => {
        err ? reject(err)
          : resolve(manufacturer);
      });
  });
};

manufacturerSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Manufacturer.findById(id)
      .exec((err, manufacturer) => {
        err ? reject(err)
          : resolve(manufacturer);
      });
  });
}

manufacturerSchema.statics.count = () => {
  return new Promise((resolve, reject) => {
    Manufacturer.countDocuments()
      .exec((err, manufacturer) => {
        err ? reject(err)
          : resolve(manufacturer);
      });
  });
}

manufacturerSchema.statics.create = (manufacturer) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(manufacturer)) {
      return reject(new TypeError('Manufacturer is not a valid object.'));
    }

    let _manufacturer = new Manufacturer(manufacturer);
    _manufacturer.save((err, saved) => {
      err ? reject(err)
        : resolve(_manufacturer);
    });
  });
}

manufacturerSchema.statics.update = (_id, manufacturer) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Manufacturer.findByIdAndUpdate(_id, {
      $set: manufacturer
    })
      .exec((err, manufacturer) => {
        err ? reject(err)
          : resolve(manufacturer);
      })
  });
}

manufacturerSchema.statics.updateImage = (_id, manufacturer) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Manufacturer.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': manufacturer.image } })
      .exec((err, manufacturer) => {
        err ? reject(err)
          : resolve(manufacturer);
      })
  });
}

manufacturerSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Manufacturer.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Manufacturer = mongoose.model('Manufacturer', manufacturerSchema);

module.exports = Manufacturer;
