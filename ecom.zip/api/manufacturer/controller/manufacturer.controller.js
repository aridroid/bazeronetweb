'use strict';

const multer = require('multer');
const fs = require('fs');
const createError = require('http-errors');
const ManufacturerDAO = require('../dao/manufacturer.dao');

// SET STORAGE
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, req.params.id + '.png');
  }
})

const upload = multer({ storage: storage }).fields([
  { name: 'image', maxCount: 1 }
]);

module.exports = class ManufacturerController {
  static async getAll(req, res) {
    try {
      const manufacturers = await ManufacturerDAO.getAll();
      res.status(200).json(manufacturers);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async getById(req, res) {
    try {
      const manufacturers = await ManufacturerDAO.getById(req.params.id);
      res.status(200).json(manufacturers);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async count(req, res) {
    try {
      const manufacturers = await ManufacturerDAO.count();
      res.status(200).json(manufacturers);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async create(req, res) {
    let _manufacturer = req.body;

    try {
      const manufacturers = await ManufacturerDAO.create(_manufacturer);
      res.status(200).json(manufacturers);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async update(req, res) {
    let _id = req.params.id;
    let _manufacturer = req.body;

    try {
      const manufacturers = await ManufacturerDAO.update(_id, _manufacturer);
      res.status(200).json(manufacturers);
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static async delete(req, res) {
    let _id = req.params.id;
    if (fs.existsSync('uploads/' + _id + '.png')) {
      fs.unlinkSync('uploads/' + _id + '.png');
    }

    try {
      const manufacturers = await ManufacturerDAO.delete(_id);
      res.status(200).end();
    } catch (err) {
      res.status(400).json(createError(400, err));
    }
  }

  static uploadImage(req, res) {
    let _id = req.params.id;
    let _manufacturer = {};

    upload(req, res, function (err) {
      if (err) {
        return res.status(400).json(err);
      }
      const fileName = req.files.image[0].filename;
      _manufacturer.image = fileName;

      ManufacturerDAO
        .updateImage(_id, _manufacturer)
        .then(manufacturers => res.status(200).json(manufacturers))
        .catch(error => res.status(400).json(error));
    });
  }
}

