'use strict';

let mongoose = require('mongoose');
const Promise = require('bluebird');
const _ = require('lodash');
const fs = require('fs');
var Jimp = require('jimp');

const bannerSchema = require('../model/banner.model');

bannerSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
    let _query = {};

    Banner.find(_query)
      .sort('sort_order')
      .exec((err, banner) => {
        err ? reject(err)
          : resolve(banner);
      });
  });
};

bannerSchema.statics.getById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError('Id is not defined.'));
    }

    Banner.findById(id)
      .exec((err, banner) => {
        err ? reject(err)
          : resolve(banner);
      });
  });
}

bannerSchema.statics.create = (banner) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(banner)) {
      return reject(new TypeError('Banner is not a valid object.'));
    }

    let _banner = new Banner(banner);
    _banner.save((err, saved) => {
      err ? reject(err)
        : resolve(_banner);
    });
  });
}

bannerSchema.statics.update = (_id, banner) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Banner.findByIdAndUpdate(_id, {
      $set: banner
    })
      .exec((err, banner) => {
        err ? reject(err)
          : resolve(banner);
      })
  });
}

bannerSchema.statics.updateImage = (_id, banner) => {
  return new Promise((resolve, reject) => {
    if (!_id) {
      return reject(new TypeError("Id is not defined."));
    }

    Banner.findOneAndUpdate({ _id: _id },
      { '$set': { 'image': banner.image } })
      .exec((err, banner) => {
        err ? reject(err)
          : resolve(banner);
      })
  });
}

bannerSchema.statics.delete = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError('Id is not a valid string.'));
    }

    Banner.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err)
          : resolve();
      });
  });
}

const Banner = mongoose.model('Banner', bannerSchema);

module.exports = Banner;
