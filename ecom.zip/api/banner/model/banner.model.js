'use strict';

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const _bannerSchema = mongoose.Schema({
    name: { type: String },
    description: { type: String },
    link: { type: String, required: true },
    image: { type: String },
    status: { type: Boolean, default: true },
    sort_order: { type: Number, required: true }
}, { timestamps: { createdAt: 'date_added', updatedAt: 'date_modified' } })

_bannerSchema.plugin(uniqueValidator, { message: 'Banner {PATH} should be unique.' });
module.exports = _bannerSchema;
