'use strict';

const BannerController = require('../controller/banner.controller');
const AuthTokenService = require('../../../commons/auth-token.service');

module.exports = class BannerRoutes {
  static init(router) {
    router
      .route('/api/banner')
      //.get(AuthTokenService.isAuthenticated)
      .get(BannerController.getAll)
      .post(BannerController.create);

    router
      .route('/api/banner/:id')
      //.get(AuthTokenService.isAuthenticated)
      .post(BannerController.uploadImage)
      .put(BannerController.update)
      .get(BannerController.getById)
      .delete(BannerController.delete);

    router
      .route('/api/banner/image/:id')
      //.get(AuthTokenService.isAuthenticated)
      .put(BannerController.uploadImage);
  }
}
