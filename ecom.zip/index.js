'use strict';

require('./server');
